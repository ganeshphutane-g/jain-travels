const countries = [
  "United State",
  "India",
  "France",
  "Germany",
  "Japan",
  "Australia",
];

let index = 0;
const countryEl = document.getElementById("country-name");

document.addEventListener("DOMContentLoaded", () => {
  if (!countryEl) return;

  countryEl.textContent = countries[0];

  setInterval(() => {
    index = (index + 1) % countries.length;
    countryEl.textContent = countries[index];
  }, 200);
});
